package com.imp.springboot.crud.employee.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

   
    private String result;

   

public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	/*	@NotBlank(message = "Name is mandatory")
    private String name;
*/
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

   /* public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }*/
    
    @NotBlank(message = "arth is mandatory")
    private String arth;


	public String getArth() {
		return arth;
	}

	public void setArth(String arth) {
		this.arth = arth;
	}
}
