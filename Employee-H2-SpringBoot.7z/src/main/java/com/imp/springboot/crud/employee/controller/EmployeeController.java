package com.imp.springboot.crud.employee.controller;

import com.imp.springboot.crud.employee.model.Employee;
import com.imp.springboot.crud.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
public class EmployeeController {

    private EmployeeService service;

    @Autowired
    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping
    public String showAllEmployees(Model model) {
        model.addAttribute("employees", service.findAll());
        return "employees";
    }

    @GetMapping("/new-employee")
    public String showEmployeeCreationForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "new-employee";
    }

    @PostMapping(value = "/add", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String addNewEmployee(@Valid @ModelAttribute Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "new-employee";
        }
        service.save(employee);
        model.addAttribute("employees", service.findAll());
        return "employees";
    }

    @GetMapping("/{id}")
    public String showEmployeedById(@PathVariable Long id, Model model) {
        Employee employee = service.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid employee Id:" + id));
        model.addAttribute("employee", employee);
        return "edit-employee";
    }

    @PostMapping("/{id}/update")
    public String updateEmployee(@PathVariable Long id, @Valid @ModelAttribute Employee employee, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "edit-employee";
        }
        service.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid employee Id:" + id));
        service.save(employee);
        model.addAttribute("employees", service.findAll());
        return "employees";
    }

    @PostMapping("/{id}/delete")
    public String deleteEmployee(@PathVariable Long id, Model model) {
        service.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid employee Id:" + id));
        service.deleteById(id);
        model.addAttribute("employees", service.findAll());
        return "employees";
    }
}
