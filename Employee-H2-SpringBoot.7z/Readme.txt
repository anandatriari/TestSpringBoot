1) unzip the file Employee-H2-SpringBoot.7z
2) Eclipse ->File->Import->Maven-->Existing Maven Projects
3) Right click on Project Employee-H2-SpringBoot project select Refresh and Run As and select Maven Clean. (you will get Build success)
4) Also do the Run as Maven generate resources and Maven install.
5) Right click on Application.java file, select Run as -->Java Application and Tomcat gets started.
6) Test the Application, hit url     http://localhost:8080 in the brower address bar
7) Test the H2 database , hit url   http://localhost:8080/h2 and check Employee table details
